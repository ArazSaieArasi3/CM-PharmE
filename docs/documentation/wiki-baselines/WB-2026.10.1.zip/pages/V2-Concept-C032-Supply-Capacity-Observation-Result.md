# Supply Capacity Observation Result

> **Version scope:** V2  
> **Status:** pending semantic review  
> **Updated:** 2026-09-24

> Generated concept reference from the V2 Concept Evidence Passport and formal ontology. This page does not create or approve semantics.

## Canonical definition
> Information object recording evidence or assessment about supply capacity.

## Ontological role
| Field | Value |
|---|---|
| Concept ID | `CMPE-V2-C032` |
| Domain | [[V2 Module 06 Ecosystem Observation|Ecosystem Observation]] |
| Layer | Core |
| OntoUML stereotype | Subkind |
| Formal entity type | OWL Class |
| Formal IRI | `cmpe:SupplyCapacityObservationResult` |

## Generalization
[[V2 Concept C046 Observation Result|ObservationResult]]

## Principal formal relations
No object property declares this concept as an explicit OWL domain or range endpoint.

Properties whose endpoint is formally unspecified are not inferred into this list.

## Constraints / SHACL relevance
- Protected conceptual distinction(s): `SupplyCapacityObservationResult ≠ SupplyCapacity`.
- Current SHACL source does not directly reference `cmpe:SupplyCapacityObservationResult`. This is a syntactic reference observation, not a completeness judgment.
- See [[V2 Formal Ontology and SHACL]] for constraint semantics and validation scope.

## Evidence and provenance
- **Dataset/source evidence:** P5/ESMP/C1
- **Held-out evidence:** —
- **Other support:** PR1/O3/M1/M2
- **Review focus:** confirm the registered definition and stereotype against admitted evidence.

## V1 lineage
- **Migration treatment:** C0011 → refine/split
- See [[V1 to V2 Concept Migration]] and [[V1 to V2 Research Evolution]] for cross-version interpretation.

## Structural example
No explicit object-property domain/range example is selected for this concept.

This is a structural example grounded in explicit formal endpoints, not an instance-data assertion.

## Boundary / non-example
Protected conceptual distinction(s): `SupplyCapacityObservationResult ≠ SupplyCapacity`.

A source record, identifier or label should not be treated as this domain entity unless the governing ontology/evidence relation explicitly supports that interpretation.

## Related implementation, mappings and visual/evaluation context
- [[V2 Data Infrastructure]]
- [[V2 Evaluation E1-E13|CM-PharmE 2.0 Evaluation Framework]]
- [[Diagram Standards and Inventory]]
- Mapping authority: `v2/data/mappings/ontology-rdb-mapping.csv`
- Concept/data mapping evidence remains governed by the mapping registry and E6/E10 artifacts; this generated page does not infer a direct table mapping.

## Review state
- **Passport review state:** pending
- **Evidence status:** registered_not_human_approved
- **Human/author disposition:** Pending

Pending status remains pending until the governed semantic review records a disposition.

## Authoritative sources
- Concept Evidence Passport: `v2/review/concepts/passports/032-supply-capacity-observation-result.md`
- conceptual registry: `v2/ontouml/cm-pharme-v2.conceptual-model.json`
- formal source: `v2/ontology/source/modules/10-core.ttl`
- review/evolution package: `v2/review/version-evolution.md`

---

<details>
<summary>Documentation record</summary>

- **Page scope:** V2
- **Documentation maturity:** Stable-to-date / Evolving
- **Authoritative source:** V2 Concept Evidence Passport, conceptual registry and formal ontology
- **Last synchronized:** 2026-09-24
- **Last synchronized ref:** v2/research-program@1226b0a5484f8f5d3a8d214e0d0f52f066b88999
- **Related issues/PRs:** #213, #234
- **Evidence status:** Generated concept reference; registered review/evidence status preserved
- **Future refresh:** #213 / #214 as applicable
- **Wiki baseline:** WB-2026.09.1

</details>
